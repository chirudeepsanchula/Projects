# Importing the libraries
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
from sklearn.preprocessing import LabelEncoder


# Reading the csv file
df = pd.read_csv('insurance.csv')
le = LabelEncoder()
df['sex'] = le.fit_transform(df['sex'])
df['smoker'] = le.fit_transform(df['smoker'])
df['region'] = le.fit_transform(df['region'])

# Setting up the dashboard layout and title
st.set_page_config(
    page_title="Health Insurance Dashboard",
    page_icon="💊",
    layout="wide",
)
st.title('Health Insurance Dashboard')

# Creating a sidebar
st.sidebar.title('Options')
# Creating a slider to select the number of bins for the histogram
bins = st.sidebar.slider('Number of bins for the histogram', 10, 50, 20)
# Creating a checkbox to show the summary statistics
show_stats = st.sidebar.checkbox('Show summary statistics')
# Creating a selectbox to choose the theme color
theme = st.sidebar.selectbox('Choose the theme color', ['coolwarm', 'viridis', 'plasma'])

# Displaying the data in a table
st.subheader('Data')
st.dataframe(df)

# Displaying the summary statistics of the data if checked
if show_stats:
    st.subheader('Summary Statistics')
    st.write(df.describe())

# Displaying the correlation matrix and the scatter plots of the data
st.subheader('Correlation and Scatter Plots')
# Creating a multi-column layout
col1, col2 = st.columns(2)
# Displaying the correlation matrix in the first column
with col1:
    corr = df.corr()
    fig, ax = plt.subplots(figsize=(10,8))
    sns.heatmap(corr, annot=True, cmap=theme, ax=ax)
    st.pyplot(fig)
# Displaying the scatter plots in the second column
with col2:
    fig, ax = plt.subplots(figsize=(10,8))
    sns.scatterplot(x='age', y='charges', hue='smoker', data=df, ax=ax)
    st.pyplot(fig)

    fig, ax = plt.subplots(figsize=(10,8))
    sns.scatterplot(x='bmi', y='charges', hue='smoker', data=df, ax=ax)
    st.pyplot(fig)

# Displaying the box plots of the data
st.subheader('Box Plots')
# Creating a multi-column layout
col1, col2, col3 = st.columns(3)
# Displaying the box plot for sex in the first column
with col1:
    fig, ax = plt.subplots(figsize=(10,8))
    sns.boxplot(x='sex', y='charges', data=df, ax=ax)
    st.pyplot(fig)
# Displaying the box plot for smoker in the second column
with col2:
    fig, ax = plt.subplots(figsize=(10,8))
    sns.boxplot(x='smoker', y='charges', data=df, ax=ax)
    st.pyplot(fig)
# Displaying the box plot for region in the third column
with col3:
    fig, ax = plt.subplots(figsize=(10,8))
    sns.boxplot(x='region', y='charges', data=df, ax=ax)
    st.pyplot(fig)

# Displaying the insights and recommendations in an expander
st.subheader('Insights and Recommendations')
with st.expander('Click here to see the insights and recommendations'):
    st.markdown("""
    - The charges variable is positively correlated with age, bmi, and smoker, and weakly correlated with children and region. This means that older, heavier, and smoking customers tend to have higher medical costs than younger, lighter, and non-smoking customers. The number of children and the region of residence have little impact on the charges.
    - The charges variable has a skewed distribution, with most values below 15,000 and some outliers above 40,000. This may indicate that there are some customers with very high medical needs or risks that drive up the average charges.
    - The sex variable has no significant effect on the charges, as the box plot shows that the median and the interquartile range are almost the same for both males and females. This may suggest that the insurance company does not discriminate based on gender, or that gender is not a relevant factor for predicting charges.
    - The smoker variable has a strong effect on the charges, as the box plot and the scatter plot show that the smokers have much higher median and variance of charges than the non-smokers. This may indicate that smoking is a major risk factor for health problems and medical expenses, and that the insurance company charges more for smokers to cover the risk.
    - The region variable has a weak effect on the charges, as the box plot and the scatter plot show that the charges are similar across the four regions, with some slight differences. The southeast region has the highest median and variance of charges, followed by the northeast, the northwest, and the southwest. This may indicate that there are some regional differences in the health care costs, quality, or accessibility, or that there are some confounding factors, such as lifestyle, income, or education, that affect the charges.
    - Based on these insights, some recommendations for improving the health insurance business are:
      - Focus on the most significant variables, such as age, bmi, and smoker, as the predictors of charges, and use them to segment the customers into different risk groups and charge them accordingly.
      - Investigate the outliers in the charges variable, and identify the reasons for their high medical costs. If they are due to chronic or rare diseases, consider offering them special plans or discounts to retain them as loyal customers. If they are due to fraud or abuse, consider implementing stricter policies or penalties to prevent them from harming the business.
      - Conduct more research on the sex and region variables, and determine if they have any hidden or indirect effects on the charges. For example, check if there are any interactions or correlations between sex and smoker, or region and bmi, that may affect the charges. If so, adjust the pricing strategy accordingly.
      - Encourage the customers to adopt healthier habits, such as quitting smoking, losing weight, or exercising regularly, and reward them with lower premiums or incentives. This will not only reduce the medical costs and risks, but also improve the customer satisfaction and loyalty.
    """)
    
st.subheader('Conclusion')
with st.expander('Click here to see the conclusion of the exploratory data analysis.'):
    st.markdown("""
    The exploratory data analysis on the health insurance dataset revealed some interesting patterns and relationships between the input and output variables. The analysis also provided some insights and recommendations for improving the health insurance business, based on the correlation coefficients, the scatter plots, and the box plots. The analysis also identified some potential challenges and limitations of the data, such as the skewness and outliers of the charges variable, the insignificance of the sex and region variables, and the multicollinearity among some input variables. These issues may require further data preprocessing and transformation, as well as the use of other machine learning techniques, to achieve a better predictive performance.
    """)

# Displaying the linear regression model and the r-squared score
st.subheader('Linear Regression Model')
X = df[['age', 'bmi', 'smoker']]
y = df['charges']
model = LinearRegression()
model.fit(X, y)
y_pred = model.predict(X)
r2 = r2_score(y, y_pred)
st.write(f'The equation of the linear regression model is: charges = {model.intercept_:.2f} + {model.coef_[0]:.2f} * age + {model.coef_[1]:.2f} * bmi + {model.coef_[2]:.2f} * smoker')
st.write(f'The r-squared score of the linear regression model is: {r2:.2f}')
